<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Payeer\\Providers\\PayeerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Payeer\\Providers\\PayeerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);