<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Certificate\\Providers\\CertificateServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Certificate\\Providers\\CertificateServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);