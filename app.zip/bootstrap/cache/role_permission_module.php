<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\RolePermission\\Providers\\RolePermissionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\RolePermission\\Providers\\RolePermissionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);