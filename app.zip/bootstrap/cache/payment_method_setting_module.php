<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PaymentMethodSetting\\Providers\\PaymentMethodSettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PaymentMethodSetting\\Providers\\PaymentMethodSettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);