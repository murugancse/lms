<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Razorpay\\Providers\\RazorpayServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Razorpay\\Providers\\RazorpayServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);