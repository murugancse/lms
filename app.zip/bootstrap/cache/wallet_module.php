<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Wallet\\Providers\\WalletServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Wallet\\Providers\\WalletServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);