<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ModuleManager\\Providers\\ModuleManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ModuleManager\\Providers\\ModuleManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);