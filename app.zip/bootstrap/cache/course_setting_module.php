<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CourseSetting\\Providers\\CourseSettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CourseSetting\\Providers\\CourseSettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);