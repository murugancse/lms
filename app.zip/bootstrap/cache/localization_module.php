<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Localization\\Providers\\LocalizationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Localization\\Providers\\LocalizationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);