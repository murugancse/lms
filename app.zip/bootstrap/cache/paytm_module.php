<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Paytm\\Providers\\PaytmServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Paytm\\Providers\\PaytmServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);