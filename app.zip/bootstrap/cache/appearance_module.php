<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Appearance\\Providers\\AppearanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Appearance\\Providers\\AppearanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);