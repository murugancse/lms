<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Instamojo\\Providers\\InstamojoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Instamojo\\Providers\\InstamojoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);