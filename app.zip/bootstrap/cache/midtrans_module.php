<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Midtrans\\Providers\\MidtransServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Midtrans\\Providers\\MidtransServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);