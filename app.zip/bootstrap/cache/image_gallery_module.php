<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ImageGallery\\Providers\\ImageGalleryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ImageGallery\\Providers\\ImageGalleryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);