<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FrontendManage\\Providers\\FrontendManageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FrontendManage\\Providers\\FrontendManageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);