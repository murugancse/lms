<?php return array (
  'anandsiddharth/laravel-paytm-wallet' => 
  array (
    'providers' => 
    array (
      0 => 'Anand\\LaravelPaytmWallet\\PaytmWalletServiceProvider',
    ),
    'aliases' => 
    array (
      'PaytmWallet' => 'Anand\\LaravelPaytmWallet\\Facades\\PaytmWallet',
    ),
  ),
  'brian2694/laravel-toastr' => 
  array (
    'providers' => 
    array (
      0 => 'Brian2694\\Toastr\\ToastrServiceProvider',
    ),
    'aliases' => 
    array (
      'Toastr' => 'Brian2694\\Toastr\\Facades\\Toastr',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'hisorange/browser-detect' => 
  array (
    'providers' => 
    array (
      0 => 'hisorange\\BrowserDetect\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Browser' => 'hisorange\\BrowserDetect\\Facade',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'joisarjignesh/bigbluebutton' => 
  array (
    'providers' => 
    array (
      0 => 'JoisarJignesh\\Bigbluebutton\\BigbluebuttonServiceProvider',
    ),
    'aliases' => 
    array (
      'Bigbluebutton' => 'JoisarJignesh\\Bigbluebutton\\Facades\\Bigbluebutton',
    ),
  ),
  'laravel/passport' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Passport\\PassportServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'macsidigital/laravel-api-client' => 
  array (
    'providers' => 
    array (
      0 => 'MacsiDigital\\API\\Providers\\APIServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'macsidigital/laravel-oauth2-client' => 
  array (
    'providers' => 
    array (
      0 => 'MacsiDigital\\OAuth2\\Providers\\OAuth2ServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nwidart/laravel-modules' => 
  array (
    'providers' => 
    array (
      0 => 'Nwidart\\Modules\\LaravelModulesServiceProvider',
    ),
    'aliases' => 
    array (
      'Module' => 'Nwidart\\Modules\\Facades\\Module',
    ),
  ),
  'spn/laravel-zoom-api' => 
  array (
    'providers' => 
    array (
      0 => 'MacsiDigital\\Zoom\\Providers\\ZoomServiceProvider',
    ),
    'aliases' => 
    array (
      'Zoom' => 'MacsiDigital\\Zoom\\Facades\\Zoom',
    ),
  ),
  'spondonit/lms-service' => 
  array (
    'providers' => 
    array (
      0 => 'SpondonIt\\LmsService\\SpondonItLmsServiceProvider',
    ),
  ),
  'spondonit/service' => 
  array (
    'providers' => 
    array (
      0 => 'SpondonIt\\Service\\SpondonItServiceProvider',
    ),
  ),
  'stevebauman/location' => 
  array (
    'providers' => 
    array (
      0 => 'Stevebauman\\Location\\LocationServiceProvider',
    ),
    'aliases' => 
    array (
      'Location' => 'Stevebauman\\Location\\Facades\\Location',
    ),
  ),
  'unicodeveloper/laravel-paystack' => 
  array (
    'providers' => 
    array (
      0 => 'Unicodeveloper\\Paystack\\PaystackServiceProvider',
    ),
    'aliases' => 
    array (
      'Paystack' => 'Unicodeveloper\\Paystack\\Facades\\Paystack',
    ),
  ),
  'vimeo/laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Vimeo\\Laravel\\VimeoServiceProvider',
    ),
    'aliases' => 
    array (
      'Vimeo' => 'Vimeo\\Laravel\\Facades\\Vimeo',
    ),
  ),
);